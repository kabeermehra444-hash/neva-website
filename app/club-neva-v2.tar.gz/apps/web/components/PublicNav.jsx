'use client';

import { useRouter, usePathname } from 'next/navigation';
import { useCartCount } from '@/lib/cart';
import { isLoggedIn, isApprovedMember, clearStoredMember } from '@/lib/auth';
import { useState, useEffect } from 'react';

export default function PublicNav() {
  const router = useRouter();
  const pathname = usePathname();
  const cartCount = useCartCount();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [approved, setApproved] = useState(false);

  useEffect(() => {
    setLoggedIn(isLoggedIn());
    setApproved(isApprovedMember());
  }, []);

  const navLinks = [
    { label: 'Shop', href: '/shop' },
    { label: 'Events', href: '/events' },
    { label: 'News', href: '/news-updates' },
    { label: 'About', href: '/about' },
  ];

  const isActive = (href) => pathname === href;

  return (
    <header className="fixed top-0 left-0 right-0 w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      {/* Desktop */}
      <div className="hidden lg:grid grid-cols-3 items-center max-w-[1600px] mx-auto px-8 h-20">
        <nav className="flex items-center gap-8 text-sm font-medium tracking-wide">
          {navLinks.map(link => (
            <button
              key={link.href}
              onClick={() => router.push(link.href)}
              className={`transition-colors uppercase ${isActive(link.href) ? 'text-white font-bold' : 'text-gray-400 hover:text-white'}`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="text-center">
          <button onClick={() => router.push('/')} className="font-display text-3xl font-bold uppercase tracking-widest text-white hover:text-gray-300 transition-colors">
            Club Neva
          </button>
        </div>

        <div className="flex items-center justify-end gap-6 text-sm font-medium tracking-wide">
          <button onClick={() => router.push('/checkout')} className="text-white hover:text-gray-300 transition-colors relative">
            <i className="ph ph-shopping-cart text-xl"></i>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-white text-black text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                {cartCount}
              </span>
            )}
          </button>
          <div className="h-4 w-px bg-white/20 mx-2"></div>
          {approved ? (
            <button onClick={() => router.push('/portal-dashboard')} className="text-white hover:text-gray-300 transition-colors uppercase">
              Portal
            </button>
          ) : (
            <button onClick={() => router.push('/login')} className="text-white hover:text-gray-300 transition-colors uppercase">
              Login
            </button>
          )}
          <button
            onClick={() => router.push('/membership-apply')}
            className="px-5 py-2.5 bg-white text-black uppercase font-bold text-xs tracking-wider rounded hover:bg-gray-200 active:scale-95 transition-all"
          >
            Apply
          </button>
        </div>
      </div>

      {/* Mobile */}
      <div className="lg:hidden flex items-center justify-between px-6 h-20">
        <button onClick={() => router.push('/')} className="font-display text-2xl font-bold uppercase tracking-widest text-white">
          Club Neva
        </button>
        <div className="flex items-center gap-4">
          <button onClick={() => router.push('/checkout')} className="text-white relative">
            <i className="ph ph-shopping-cart text-2xl"></i>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-white text-black text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                {cartCount}
              </span>
            )}
          </button>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="text-white">
            <i className={`ph ph-${mobileOpen ? 'x' : 'list'} text-2xl`}></i>
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileOpen && (
        <div className="lg:hidden bg-black/95 border-t border-white/10 px-6 py-4 space-y-4">
          {navLinks.map(link => (
            <button
              key={link.href}
              onClick={() => { router.push(link.href); setMobileOpen(false); }}
              className="block w-full text-left text-sm font-medium uppercase tracking-wide text-gray-300 hover:text-white transition-colors py-2"
            >
              {link.label}
            </button>
          ))}
          <div className="border-t border-white/10 pt-4 flex flex-col gap-3">
            {approved ? (
              <button
                onClick={() => { router.push('/portal-dashboard'); setMobileOpen(false); }}
                className="text-left text-sm font-medium uppercase tracking-wide text-gray-300 hover:text-white transition-colors py-2"
              >
                Member Portal
              </button>
            ) : (
              <button
                onClick={() => { router.push('/login'); setMobileOpen(false); }}
                className="text-left text-sm font-medium uppercase tracking-wide text-gray-300 hover:text-white transition-colors py-2"
              >
                Login
              </button>
            )}
            <button
              onClick={() => { router.push('/membership-apply'); setMobileOpen(false); }}
              className="px-5 py-3 bg-white text-black uppercase font-bold text-xs tracking-wider rounded hover:bg-gray-200 transition-all text-center"
            >
              Apply for Membership
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
