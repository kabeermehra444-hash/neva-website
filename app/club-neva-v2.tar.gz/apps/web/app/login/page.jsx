'use client';

import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import PublicNav from '@/components/PublicNav';
import { setStoredMember, popLoginRedirect, isApprovedMember } from '@/lib/auth';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isApprovedMember()) {
      router.replace('/portal-dashboard');
    }
  }, [router]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/members');
      if (!res.ok) throw new Error('Server error');
      const members = await res.json();
      if (!Array.isArray(members)) throw new Error('Invalid response');

      const member = members.find(m => m.email?.toLowerCase() === email.toLowerCase().trim());

      if (!member) {
        setError("No account found with that email address.");
        setLoading(false);
        return;
      }

      const isApproved = member.status === 'approved' || member.status === 'active';

      if (!isApproved) {
        if (member.status === 'pending') {
          setError("Your application is pending review. We'll notify you when approved.");
        } else if (member.status === 'denied') {
          setError("Your membership application was not approved. Contact us for more info.");
        } else {
          setError("Your account is not active. Please contact support.");
        }
        setLoading(false);
        return;
      }

      setStoredMember({
        id: member.id,
        email: member.email,
        name: ((member.first_name || '') + ' ' + (member.last_name || '')).trim() || email.split('@')[0],
        first_name: member.first_name,
        last_name: member.last_name,
        status: 'approved',
        is_admin: member.is_admin || false,
        rank_label: member.rank_label,
        wins: member.wins,
        losses: member.losses,
        events_played: member.events_played,
        streak: member.streak,
        neva_cash_balance: member.neva_cash_balance || 0,
        loginTime: new Date().toISOString(),
      });

      const redirect = popLoginRedirect();
      if (redirect) {
        window.location.href = redirect;
      } else {
        router.push('/portal-dashboard');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Login failed. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="font-sans bg-black text-white antialiased min-h-screen">
      <PublicNav />
      <main className="pt-20 min-h-screen flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          <button onClick={() => router.back()} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-8 text-sm uppercase tracking-wide">
            <i className="ph ph-arrow-left"></i> Back
          </button>
          <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-10">
            <div className="text-center mb-8">
              <div className="w-16 h-16 border border-white/20 rounded-2xl bg-white/5 flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(255,255,255,0.1)] mx-auto">
                <i className="ph-fill ph-user text-3xl text-white"></i>
              </div>
              <h1 className="font-display text-3xl font-medium uppercase tracking-tight mb-2">Member Login</h1>
              <p className="text-gray-400 text-sm">Access your Club NEVA account</p>
            </div>
            <form className="space-y-6" onSubmit={handleLogin}>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2 uppercase tracking-wide">Email Address</label>
                <input type="email" id="email" required autoComplete="email"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-white/50 transition-colors"
                  placeholder="member@email.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-2 uppercase tracking-wide">Password</label>
                <input type="password" id="password" required autoComplete="current-password"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-white/50 transition-colors"
                  placeholder="Enter your password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              {error && (
                <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                  <p className="text-red-400 text-sm">{error}</p>
                </div>
              )}
              <button type="submit" disabled={loading}
                className="w-full py-4 bg-white text-black font-bold uppercase text-sm tracking-widest rounded-lg hover:bg-gray-200 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                {loading ? 'Signing In...' : 'Sign In'}
              </button>
            </form>
            <div className="mt-8 pt-8 border-t border-white/10 text-center">
              <p className="text-gray-400 text-sm mb-4">Not a member yet?</p>
              <button onClick={() => router.push('/membership-apply')} className="text-white font-bold uppercase text-sm tracking-widest hover:text-gray-300 transition-colors">
                Apply for Membership →
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
