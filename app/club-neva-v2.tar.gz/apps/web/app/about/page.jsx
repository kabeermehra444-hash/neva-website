'use client';
import { useRouter } from 'next/navigation';
import PublicNav from '@/components/PublicNav';
import Footer from '@/components/Footer';

export default function AboutPage() {
  const router = useRouter();
  return (
    <div className="font-sans bg-black text-white antialiased">
      <PublicNav />
      <main className="pt-20">

        {/* Hero */}
        <section className="relative py-32 md:py-48 overflow-hidden">
          <div className="absolute inset-0">
            <img src="https://images.unsplash.com/photo-1541534741688-6038c636f446?q=80&w=2400&auto=format&fit=crop" alt="Court" className="w-full h-full object-cover opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black"></div>
          </div>
          <div className="relative z-10 max-w-5xl mx-auto px-6">
            <p className="text-gray-500 text-xs uppercase tracking-widest font-bold mb-4">Our Story</p>
            <h1 className="font-display text-6xl md:text-9xl font-medium tracking-tighter uppercase mb-8 leading-[0.85]">
              The Philosophy<br />of NEVA.
            </h1>
            <p className="text-xl md:text-2xl text-gray-400 max-w-3xl font-light leading-relaxed">
              We believe in the intersection of high-stakes competition and community. We don't just host games — we curate excellence.
            </p>
          </div>
        </section>

        {/* Manifesto */}
        <section className="py-24 border-t border-white/10">
          <div className="max-w-5xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div>
                <p className="text-gray-500 text-xs uppercase tracking-widest font-bold mb-4">Our Foundation</p>
                <h2 className="font-display text-4xl md:text-5xl uppercase mb-8 font-medium tracking-tight">Exclusivity<br />by Design.</h2>
                <div className="space-y-6 text-gray-400 leading-relaxed text-lg">
                  <p>Club NEVA was founded on the principle that competition thrives in an exclusive community. By limiting membership to serious practitioners, we ensure that every event, every round robin, and every interaction meets a rigorous standard.</p>
                  <p>Our members aren't just players — they are the standard-bearers of a new movement in competitive athletics. Through our internal currency system and verified ranking mechanisms, we maintain an environment that rewards dedication, performance, and integrity.</p>
                </div>
              </div>
              <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-gray-900">
                <img src="https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?q=80&w=1200&auto=format&fit=crop" alt="Competition" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Bar */}
        <section className="py-16 border-y border-white/10 bg-white/5">
          <div className="max-w-5xl mx-auto px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { val: 'Weekly', label: 'Round Robins' },
                { val: '100%', label: 'Member Approved' },
                { val: 'Live', label: 'Stat Tracking' },
                { val: 'NEVA', label: 'Cash Rewards' },
              ].map(s => (
                <div key={s.label}>
                  <p className="font-display text-4xl md:text-5xl font-bold mb-2">{s.val}</p>
                  <p className="text-gray-500 text-sm uppercase tracking-widest font-medium">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Core Pillars */}
        <section className="py-24 border-b border-white/10">
          <div className="max-w-5xl mx-auto px-6">
            <p className="text-gray-500 text-xs uppercase tracking-widest font-bold mb-4 text-center">What We Stand For</p>
            <h2 className="font-display text-4xl md:text-5xl uppercase mb-16 text-center font-medium tracking-tight">Core Pillars</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { icon: 'ph-sword', title: 'Competition', desc: 'The primary objective. We host events that challenge your limits, ensuring consistent growth for every member on every court.' },
                { icon: 'ph-users', title: 'Community', desc: 'A network of elite athletes. We foster mutual respect, shared ambition, and continuous connection between all members.' },
                { icon: 'ph-medal', title: 'Integrity', desc: 'Performance is our currency. Verified rankings and transparent leaderboards protect the sanctity of our competition.' },
              ].map(p => (
                <div key={p.title} className="bg-white/5 border border-white/10 p-8 rounded-2xl hover:bg-white/10 transition-colors">
                  <div className="w-12 h-12 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center mb-6">
                    <i className={`ph-fill ${p.icon} text-2xl text-white`}></i>
                  </div>
                  <h3 className="font-display text-2xl uppercase font-bold mb-4">{p.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How NEVA Cash Works */}
        <section className="py-24 border-b border-white/10">
          <div className="max-w-5xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div className="aspect-video rounded-2xl overflow-hidden bg-gray-900 relative">
                <img src="https://images.unsplash.com/photo-1622228514125-9c84918e98be?q=80&w=1200&auto=format&fit=crop" alt="NEVA Cash" className="w-full h-full object-cover opacity-60" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="font-display text-6xl font-bold text-amber-400 mb-2">$$$</p>
                    <p className="text-white font-bold uppercase tracking-widest text-sm">NEVA Cash</p>
                  </div>
                </div>
              </div>
              <div>
                <p className="text-gray-500 text-xs uppercase tracking-widest font-bold mb-4">The Reward System</p>
                <h2 className="font-display text-4xl md:text-5xl uppercase mb-6 font-medium tracking-tight">Earn. Spend.<br />Compete More.</h2>
                <div className="space-y-4 text-gray-400 leading-relaxed mb-8">
                  <p>NEVA Cash is Club NEVA's internal reward currency. You earn it through wins, podium finishes, and event performance — all tracked and managed by our admin team.</p>
                  <p>Redeem your balance directly at checkout on any gear in The Armory. The more you compete, the more you earn.</p>
                </div>
                <button onClick={() => router.push('/membership-apply')} className="px-8 py-4 bg-white text-black font-bold uppercase text-sm tracking-widest rounded hover:bg-gray-200 active:scale-95 transition-all">
                  Apply to Earn
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-32 text-center">
          <div className="max-w-2xl mx-auto px-6">
            <div className="w-20 h-20 border border-white/20 rounded-2xl bg-white/5 flex items-center justify-center mb-8 mx-auto">
              <i className="ph-fill ph-seal-check text-4xl text-white"></i>
            </div>
            <h2 className="font-display text-5xl md:text-6xl uppercase mb-6 font-medium tracking-tight">Ready to Join?</h2>
            <p className="text-gray-400 mb-10 text-lg font-light leading-relaxed">Applications for the current cycle are open. Submit yours and our team will review within a few business days.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button onClick={() => router.push('/membership-apply')} className="px-10 py-4 bg-white text-black font-bold uppercase text-sm tracking-widest rounded hover:bg-gray-200 active:scale-95 transition-all">
                Apply for Membership
              </button>
              <button onClick={() => router.push('/events')} className="px-10 py-4 border border-white/30 text-white font-bold uppercase text-sm tracking-widest rounded hover:bg-white/10 active:scale-95 transition-all">
                View Events
              </button>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
