'use client';
import { useRouter } from 'next/navigation';
import PublicNav from '@/components/PublicNav';
import Footer from '@/components/Footer';

const ARTICLES = [
  { tag: 'Recap', date: 'Nov 8, 2025', title: 'Fall Classic: Upsets & Glory', excerpt: 'The definitive breakdown of last weekend\'s tournament. See who climbed the ranks and who secured the bag in the final showdown.', img: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1200&auto=format&fit=crop', featured: true },
  { tag: 'Drop', date: 'Nov 2, 2025', title: 'Winter \'25 Capsule Preview', excerpt: 'Heavyweight fabrics and court-ready silhouettes. Members get 24-hour early access and can redeem NEVA Cash on all new arrivals.', img: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop' },
  { tag: 'Feature', date: 'Oct 28, 2025', title: 'Community Spotlight: Marcus C.', excerpt: 'Meet the current #1 on the leaderboard. We sit down with Marcus to discuss his dominant run and what keeps him at the top.', img: 'https://images.unsplash.com/photo-1541534741688-6038c636f446?q=80&w=1200&auto=format&fit=crop' },
  { tag: 'Education', date: 'Oct 20, 2025', title: 'The Third-Drop Blueprint', excerpt: 'Mastering the third-shot drop is the single biggest unlock in competitive pickleball. Here\'s how our top players do it.', img: 'https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?q=80&w=1200&auto=format&fit=crop' },
  { tag: 'Update', date: 'Oct 12, 2025', title: 'Ranking Methodology Update', excerpt: 'We\'ve refined our internal ranking system. See how these changes impact your standing on the leaderboard this season.', img: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?q=80&w=1200&auto=format&fit=crop' },
  { tag: 'Announcement', date: 'Oct 5, 2025', title: 'New Courts Now Open', excerpt: 'We\'ve secured two additional courts at Northside Athletic Club. Tuesday night round robins now have 50% more capacity.', img: 'https://images.unsplash.com/photo-1622228514125-9c84918e98be?q=80&w=1200&auto=format&fit=crop' },
];

const TAG_COLORS = {
  Recap: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  Drop: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  Feature: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  Education: 'bg-green-500/20 text-green-400 border-green-500/30',
  Update: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  Announcement: 'bg-red-500/20 text-red-400 border-red-500/30',
};

export default function NewsUpdatesPage() {
  const router = useRouter();
  const featured = ARTICLES[0];
  const rest = ARTICLES.slice(1);

  return (
    <div className="font-sans bg-black text-white antialiased">
      <PublicNav />
      <main className="pt-20">

        {/* Header */}
        <section className="py-20 md:py-28 border-b border-white/10">
          <div className="max-w-5xl mx-auto px-6">
            <p className="text-gray-500 text-xs uppercase tracking-widest font-bold mb-4">Club NEVA</p>
            <h1 className="font-display text-6xl md:text-8xl font-medium tracking-tighter uppercase mb-6">Dispatches</h1>
            <p className="text-lg text-gray-400 max-w-2xl font-light">Event recaps, gear drops, community updates, and announcements from the courts.</p>
          </div>
        </section>

        {/* Featured Article */}
        <section className="py-16 border-b border-white/10">
          <div className="max-w-[1600px] mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-0 rounded-2xl overflow-hidden bg-white/5 border border-white/10 group cursor-pointer hover:border-white/20 transition-all">
              <div className="aspect-[4/3] md:aspect-auto overflow-hidden">
                <img src={featured.img} alt={featured.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="p-10 md:p-16 flex flex-col justify-center">
                <div className="flex items-center gap-3 mb-6">
                  <span className={`text-[11px] font-bold uppercase px-2.5 py-1 rounded border ${TAG_COLORS[featured.tag]}`}>{featured.tag}</span>
                  <span className="text-gray-500 text-sm">{featured.date}</span>
                </div>
                <h2 className="font-display text-4xl md:text-5xl font-medium uppercase tracking-tight mb-6 leading-[1]">{featured.title}</h2>
                <p className="text-gray-400 leading-relaxed mb-8 text-lg">{featured.excerpt}</p>
                <span className="text-sm font-bold uppercase tracking-widest flex items-center gap-2 group-hover:gap-3 transition-all">
                  Read Story <i className="ph ph-arrow-right"></i>
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Article Grid */}
        <section className="py-16">
          <div className="max-w-[1600px] mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {rest.map((article, i) => (
                <article key={i} className="group cursor-pointer flex flex-col bg-white/5 border border-white/10 rounded-2xl overflow-hidden hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                  <div className="aspect-[16/10] overflow-hidden">
                    <img src={article.img} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-7 flex flex-col flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <span className={`text-[11px] font-bold uppercase px-2 py-0.5 rounded border ${TAG_COLORS[article.tag]}`}>{article.tag}</span>
                      <span className="text-gray-500 text-xs">{article.date}</span>
                    </div>
                    <h3 className="font-display text-2xl font-medium uppercase leading-tight mb-3">{article.title}</h3>
                    <p className="text-gray-400 text-sm leading-relaxed mb-6 flex-1">{article.excerpt}</p>
                    <span className="text-xs font-bold uppercase tracking-widest flex items-center gap-1 group-hover:gap-2 transition-all text-gray-300">
                      Read Story <i className="ph ph-arrow-right"></i>
                    </span>
                  </div>
                </article>
              ))}

              {/* Join Widget */}
              <div className="bg-white text-black rounded-2xl overflow-hidden flex flex-col relative shadow-2xl">
                <div className="p-10 flex-1 flex flex-col">
                  <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center mb-6">
                    <i className="ph-fill ph-seal-check text-2xl text-white"></i>
                  </div>
                  <h3 className="font-display text-3xl font-medium uppercase mb-2">Join Club NEVA</h3>
                  <div className="w-10 h-1 bg-black mb-6"></div>
                  <p className="text-gray-600 mb-8 leading-relaxed text-sm">
                    Apply for access to weekly round robins, member-only leaderboards, NEVA Cash rewards, and exclusive gear drops.
                  </p>
                  <ul className="space-y-2 mb-8 text-sm font-medium">
                    {['Weekly Round Robins','Live Stat Tracking','NEVA Cash Rewards','Early Gear Access'].map(item => (
                      <li key={item} className="flex items-center gap-2">
                        <i className="ph-fill ph-check-circle text-black"></i> {item}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto space-y-3">
                    <button onClick={() => router.push('/membership-apply')} className="w-full py-3.5 bg-black text-white font-bold uppercase text-xs tracking-widest rounded hover:bg-gray-800 active:scale-95 transition-all">
                      Apply Now
                    </button>
                    <button onClick={() => router.push('/login')} className="w-full py-3.5 border-2 border-black text-black font-bold uppercase text-xs tracking-widest rounded hover:bg-gray-50 active:scale-95 transition-all">
                      Member Login
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
