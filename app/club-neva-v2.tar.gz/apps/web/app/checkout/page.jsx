'use client';

import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import PublicNav from '@/components/PublicNav';
import { getCartItems, updateCartItemQuantity, removeCartItem, clearCart, getCartSubtotal } from '@/lib/cart';
import { isApprovedMember, getStoredMember, getMemberId, refreshMemberData } from '@/lib/auth';

export default function CheckoutPage() {
  const router = useRouter();
  const [cartItems, setCartItems] = useState([]);
  const [member, setMember] = useState(null);
  const [nevaCashInput, setNevaCashInput] = useState('');
  const [nevaCashApplied, setNevaCashApplied] = useState(0);
  const [checkoutDone, setCheckoutDone] = useState(false);

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);
  const total = Math.max(0, subtotal - nevaCashApplied);

  useEffect(() => {
    setCartItems(getCartItems());

    // Load member if logged in — using correct auth lib (fixes NEVA Cash bug)
    if (isApprovedMember()) {
      const stored = getStoredMember();
      setMember(stored);
      // Refresh from DB to get latest balance
      const id = getMemberId();
      if (id) {
        refreshMemberData(id).then(fresh => { if (fresh) setMember(fresh); });
      }
    }

    const update = () => setCartItems(getCartItems());
    window.addEventListener('neva:cartUpdated', update);
    return () => window.removeEventListener('neva:cartUpdated', update);
  }, []);

  const handleQtyChange = (item, delta) => {
    const newQty = (item.quantity || 1) + delta;
    const updated = updateCartItemQuantity(item.id, item.size, newQty);
    setCartItems(updated);
    if (nevaCashApplied > 0) setNevaCashApplied(Math.min(nevaCashApplied, Math.max(0, subtotal + delta * item.price)));
  };

  const handleRemove = (item) => {
    const updated = removeCartItem(item.id, item.size);
    setCartItems(updated);
  };

  const handleClearCart = () => {
    clearCart();
    setCartItems([]);
    setNevaCashApplied(0);
    setNevaCashInput('');
  };

  const handleApplyNevaCash = () => {
    const amount = parseFloat(nevaCashInput) || 0;
    const available = member?.neva_cash_balance || 0;
    if (amount <= 0) { alert('Enter a valid amount.'); return; }
    if (amount > available) { alert(`You only have $${available} in NEVA Cash.`); return; }
    if (amount > subtotal) { alert(`Cannot exceed order total ($${subtotal.toFixed(2)}).`); return; }
    setNevaCashApplied(amount);
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) return;
    // TODO: Stripe integration. For now, simulate success.
    if (nevaCashApplied > 0 && member?.id) {
      // Deduct NEVA Cash from member balance
      try {
        const newBalance = (member.neva_cash_balance || 0) - nevaCashApplied;
        await fetch(`/api/members/${member.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ neva_cash_balance: Math.max(0, newBalance) }),
        });
        // Refresh local data
        await refreshMemberData(member.id);
      } catch (err) {
        console.error('Failed to deduct NEVA Cash:', err);
      }
    }
    clearCart();
    setCartItems([]);
    setCheckoutDone(true);
  };

  if (checkoutDone) {
    return (
      <div className="font-sans bg-white text-black antialiased min-h-screen">
        <PublicNav />
        <main className="pt-20 min-h-screen flex items-center justify-center px-6">
          <div className="text-center max-w-md">
            <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ph-fill ph-check-circle text-4xl text-green-500"></i>
            </div>
            <h1 className="font-display text-3xl font-medium uppercase tracking-tight mb-3">Order Placed!</h1>
            <p className="text-gray-600 mb-8">Thank you for your order. You'll receive a confirmation email shortly.</p>
            <div className="flex gap-3 justify-center">
              <button onClick={() => router.push('/shop')} className="px-6 py-3 bg-black text-white uppercase font-bold text-sm tracking-wider rounded hover:bg-gray-800 transition-all">
                Continue Shopping
              </button>
              {isApprovedMember() && (
                <button onClick={() => router.push('/portal-dashboard')} className="px-6 py-3 border border-black text-black uppercase font-bold text-sm tracking-wider rounded hover:bg-gray-50 transition-all">
                  My Portal
                </button>
              )}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="font-sans bg-white text-black antialiased">
      <PublicNav />

      <main className="pt-20">
        <section className="py-16 md:py-24">
          <div className="max-w-6xl mx-auto px-6">
            <button onClick={() => router.push('/shop')} className="flex items-center gap-2 text-sm text-gray-600 hover:text-black mb-8 uppercase transition-colors">
              <i className="ph ph-caret-left"></i> Back to Shop
            </button>
            <h1 className="font-display text-4xl md:text-5xl font-medium tracking-tighter uppercase mb-12">Shopping Cart</h1>

            {cartItems.length === 0 ? (
              <div className="text-center py-24">
                <i className="ph ph-shopping-cart text-6xl text-gray-300 mb-4"></i>
                <h2 className="font-display text-2xl font-medium uppercase mb-4">Your cart is empty</h2>
                <p className="text-gray-600 mb-8">Add some items from the shop to get started</p>
                <button onClick={() => router.push('/shop')} className="px-8 py-4 bg-black text-white uppercase font-bold text-sm tracking-wider rounded hover:bg-gray-800 active:scale-95 transition-all">
                  Browse Shop
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Cart Items */}
                <div className="lg:col-span-2">
                  {cartItems.map((item, idx) => (
                    <div key={`${item.id}-${item.size}-${idx}`} className="flex gap-4 py-6 border-b border-gray-200">
                      <div className="w-24 h-24 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                        {item.image ? (
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <i className="ph ph-shirt text-3xl text-gray-400"></i>
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-lg uppercase">{item.name}</h3>
                        <p className="text-sm text-gray-600">Size: {item.size}</p>
                        <div className="flex items-center gap-4 mt-3">
                          <div className="flex items-center gap-2 border border-gray-300 rounded">
                            <button onClick={() => handleQtyChange(item, -1)} className="px-3 py-1 hover:bg-gray-100 transition-colors">-</button>
                            <span className="px-3 font-medium">{item.quantity || 1}</span>
                            <button onClick={() => handleQtyChange(item, 1)} className="px-3 py-1 hover:bg-gray-100 transition-colors">+</button>
                          </div>
                          <p className="text-lg font-bold">${(item.price * (item.quantity || 1)).toFixed(2)}</p>
                        </div>
                      </div>
                      <button onClick={() => handleRemove(item)} className="text-gray-400 hover:text-red-600 transition-colors self-start mt-1">
                        <i className="ph ph-trash text-xl"></i>
                      </button>
                    </div>
                  ))}
                  <button onClick={handleClearCart} className="mt-6 text-sm text-red-600 hover:text-red-700 uppercase font-medium transition-colors">
                    Clear Cart
                  </button>
                </div>

                {/* Order Summary */}
                <div className="lg:col-span-1">
                  <div className="bg-gray-50 rounded-lg p-6 sticky top-28">
                    <h2 className="font-display text-2xl font-medium uppercase mb-6">Order Summary</h2>

                    <div className="space-y-4 mb-6 pb-6 border-b border-gray-200">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Subtotal</span>
                        <span className="font-medium">${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Shipping</span>
                        <span className="font-medium">Free</span>
                      </div>
                    </div>

                    {/* NEVA Cash — only for approved logged-in members */}
                    {member && (
                      <div className="mb-6 pb-6 border-b border-gray-200">
                        <h3 className="font-bold uppercase text-sm mb-1">NEVA Cash</h3>
                        <p className="text-xs text-gray-600 mb-3">
                          Available: <span className="font-bold">${(member.neva_cash_balance || 0).toFixed(2)}</span>
                        </p>
                        {nevaCashApplied > 0 ? (
                          <div className="bg-green-50 border border-green-200 rounded p-3">
                            <div className="flex justify-between items-center">
                              <span className="text-sm font-medium">Applied</span>
                              <span className="font-bold text-green-700">-${nevaCashApplied.toFixed(2)}</span>
                            </div>
                            <button onClick={() => { setNevaCashApplied(0); setNevaCashInput(''); }} className="text-xs text-green-700 hover:text-green-800 uppercase font-medium mt-2">Remove</button>
                          </div>
                        ) : (
                          <div className="flex gap-2">
                            <input
                              type="number" step="0.01" min="0" max={member.neva_cash_balance || 0}
                              value={nevaCashInput}
                              onChange={e => setNevaCashInput(e.target.value)}
                              className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                              placeholder="0.00"
                            />
                            <button onClick={handleApplyNevaCash} className="px-4 py-2 bg-black text-white text-xs uppercase font-bold rounded hover:bg-gray-800 transition-colors">
                              Apply
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {nevaCashApplied > 0 && (
                      <div className="flex justify-between text-sm mb-4">
                        <span className="text-gray-600">NEVA Cash Discount</span>
                        <span className="font-medium text-green-700">-${nevaCashApplied.toFixed(2)}</span>
                      </div>
                    )}

                    <div className="flex justify-between mb-6 pb-6 border-b border-gray-200">
                      <span className="font-bold uppercase">Total</span>
                      <span className="font-bold text-xl">${total.toFixed(2)}</span>
                    </div>

                    <button onClick={handleCheckout} className="block w-full py-4 bg-black text-white uppercase font-bold text-sm tracking-wider rounded hover:bg-gray-800 active:scale-95 transition-all text-center mb-4">
                      Proceed to Checkout
                    </button>
                    <p className="text-xs text-gray-500 text-center">Secure checkout</p>

                    <div className="mt-6 pt-6 border-t border-gray-200 space-y-3">
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        <i className="ph-fill ph-shield-check text-xl"></i>
                        <span>Secure checkout</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        <i className="ph-fill ph-truck text-xl"></i>
                        <span>Free shipping on all orders</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        <i className="ph-fill ph-arrow-counter-clockwise text-xl"></i>
                        <span>30-day return policy</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
