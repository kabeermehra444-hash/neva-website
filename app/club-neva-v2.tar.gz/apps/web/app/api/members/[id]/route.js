import sql from "@/app/api/utils/sql";
import { NextResponse } from "next/server";

export async function GET(request, { params }) {
  try {
    const { id } = await params;

    const result = await sql`
      SELECT id, first_name, last_name, email, phone, status, is_admin, 
             rank_label, wins, losses, events_played, streak, neva_cash_balance, 
             approved_at, created_at, updated_at 
      FROM members 
      WHERE id = ${id}
    `;

    if (result.length === 0) {
      return NextResponse.json({ error: "Member not found" }, { status: 404 });
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error fetching member:", error);
    return NextResponse.json({ error: "Failed to fetch member" }, { status: 500 });
  }
}

export async function PATCH(request, { params }) {
  try {
    const { id } = await params;
    const body = await request.json();

    const {
      first_name,
      last_name,
      email,
      phone,
      status,
      is_admin,
      rank_label,
      wins,
      losses,
      events_played,
      streak,
      neva_cash_balance
    } = body;

    const updates = [];
    const values = [];

    if (first_name !== undefined) updates.push(`first_name = $${updates.length + 1}`), values.push(first_name);
    if (last_name !== undefined) updates.push(`last_name = $${updates.length + 1}`), values.push(last_name);
    if (email !== undefined) updates.push(`email = $${updates.length + 1}`), values.push(email);
    if (phone !== undefined) updates.push(`phone = $${updates.length + 1}`), values.push(phone);
    if (status !== undefined) {
      updates.push(`status = $${updates.length + 1}`);
      values.push(status);
      if (status === 'active') {
        updates.push(`approved_at = $${updates.length + 1}`);
        values.push(new Date().toISOString());
      }
    }
    if (is_admin !== undefined) updates.push(`is_admin = $${updates.length + 1}`), values.push(is_admin);
    if (rank_label !== undefined) updates.push(`rank_label = $${updates.length + 1}`), values.push(rank_label);
    if (wins !== undefined) updates.push(`wins = $${updates.length + 1}`), values.push(wins);
    if (losses !== undefined) updates.push(`losses = $${updates.length + 1}`), values.push(losses);
    if (events_played !== undefined) updates.push(`events_played = $${updates.length + 1}`), values.push(events_played);
    if (streak !== undefined) updates.push(`streak = $${updates.length + 1}`), values.push(streak);
    if (neva_cash_balance !== undefined) updates.push(`neva_cash_balance = $${updates.length + 1}`), values.push(neva_cash_balance);

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 });
    }

    updates.push(`updated_at = NOW()`);

    const result = await sql([
      `UPDATE members SET ${updates.join(', ')} WHERE id = $${values.length + 1} RETURNING *`,
      ...values,
      id
    ]);

    if (result.length === 0) {
      return NextResponse.json({ error: "Member not found" }, { status: 404 });
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating member:", error);
    return NextResponse.json({ error: "Failed to update member" }, { status: 500 });
  }
}