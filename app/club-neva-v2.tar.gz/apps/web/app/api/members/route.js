import sql from "@/app/api/utils/sql";
import { NextResponse } from "next/server";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let members;
    if (status) {
      // active and approved are the same thing
      if (status === 'approved') {
        members = await sql`
          SELECT id, first_name, last_name, email, phone, status, is_admin, 
                 rank_label, wins, losses, events_played, streak, neva_cash_balance, 
                 approved_at, created_at, updated_at 
          FROM members 
          WHERE status IN ('active', 'approved')
          ORDER BY wins DESC, created_at DESC
        `;
      } else {
        members = await sql`
          SELECT id, first_name, last_name, email, phone, status, is_admin, 
                 rank_label, wins, losses, events_played, streak, neva_cash_balance, 
                 approved_at, created_at, updated_at 
          FROM members 
          WHERE status = ${status}
          ORDER BY wins DESC, created_at DESC
        `;
      }
    } else {
      members = await sql`
        SELECT id, first_name, last_name, email, phone, status, is_admin, 
               rank_label, wins, losses, events_played, streak, neva_cash_balance, 
               approved_at, created_at, updated_at 
        FROM members 
        ORDER BY wins DESC, created_at DESC
      `;
    }

    return NextResponse.json(members);
  } catch (error) {
    console.error("Error fetching members:", error);
    return NextResponse.json({ error: "Failed to fetch members" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      first_name, last_name, email, phone, password_hash,
      status = 'pending', is_admin = false, rank_label, neva_cash_balance = 0
    } = body;

    if (!first_name || !last_name || !email) {
      return NextResponse.json({ error: "first_name, last_name, and email are required" }, { status: 400 });
    }

    const approved_at = (status === 'active' || status === 'approved') ? new Date().toISOString() : null;

    const result = await sql`
      INSERT INTO members (first_name, last_name, email, phone, password_hash, status, is_admin, rank_label, neva_cash_balance, approved_at)
      VALUES (${first_name}, ${last_name}, ${email}, ${phone || null}, ${password_hash || null}, ${status}, ${is_admin}, ${rank_label || null}, ${neva_cash_balance}, ${approved_at})
      RETURNING *
    `;

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating member:", error);
    if (error.message?.includes('unique')) {
      return NextResponse.json({ error: "Email already exists" }, { status: 409 });
    }
    return NextResponse.json({ error: "Failed to create member" }, { status: 500 });
  }
}
