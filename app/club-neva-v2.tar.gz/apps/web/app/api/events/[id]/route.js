import sql from "@/app/api/utils/sql";
import { NextResponse } from "next/server";

export async function GET(request, { params }) {
  try {
    const { id } = await params;

    const result = await sql`
      SELECT * FROM events WHERE id = ${id}
    `;

    if (result.length === 0) {
      return NextResponse.json({ error: "Event not found" }, { status: 404 });
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error fetching event:", error);
    return NextResponse.json({ error: "Failed to fetch event" }, { status: 500 });
  }
}

export async function PATCH(request, { params }) {
  try {
    const { id } = await params;
    const body = await request.json();

    const {
      slug,
      name,
      event_type,
      description,
      event_date,
      start_time,
      end_time,
      location,
      capacity,
      spots_left,
      status,
      price,
      hero_image_url
    } = body;

    const updates = [];
    if (slug !== undefined) updates.push(sql`slug = ${slug}`);
    if (name !== undefined) updates.push(sql`name = ${name}`);
    if (event_type !== undefined) updates.push(sql`event_type = ${event_type}`);
    if (description !== undefined) updates.push(sql`description = ${description}`);
    if (event_date !== undefined) updates.push(sql`event_date = ${event_date}`);
    if (start_time !== undefined) updates.push(sql`start_time = ${start_time}`);
    if (end_time !== undefined) updates.push(sql`end_time = ${end_time}`);
    if (location !== undefined) updates.push(sql`location = ${location}`);
    if (capacity !== undefined) updates.push(sql`capacity = ${capacity}`);
    if (spots_left !== undefined) updates.push(sql`spots_left = ${spots_left}`);
    if (status !== undefined) updates.push(sql`status = ${status}`);
    if (price !== undefined) updates.push(sql`price = ${price}`);
    if (hero_image_url !== undefined) updates.push(sql`hero_image_url = ${hero_image_url}`);

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 });
    }

    updates.push(sql`updated_at = NOW()`);

    const result = await sql`
      UPDATE events 
      SET ${sql(updates.map((_, i) => updates[i]).join(', '))}
      WHERE id = ${id}
      RETURNING *
    `;

    if (result.length === 0) {
      return NextResponse.json({ error: "Event not found" }, { status: 404 });
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating event:", error);
    return NextResponse.json({ error: "Failed to update event" }, { status: 500 });
  }
}