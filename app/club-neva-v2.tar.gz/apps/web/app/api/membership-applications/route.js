import sql from "@/app/api/utils/sql";
import { NextResponse } from "next/server";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let applications;
    if (status) {
      applications = await sql`
        SELECT * FROM membership_applications 
        WHERE status = ${status}
        ORDER BY submitted_at DESC
      `;
    } else {
      applications = await sql`
        SELECT * FROM membership_applications 
        ORDER BY submitted_at DESC
      `;
    }

    return NextResponse.json(applications);
  } catch (error) {
    console.error("Error fetching membership applications:", error);
    return NextResponse.json({ error: "Failed to fetch membership applications" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      member_id,
      first_name,
      last_name,
      email,
      phone,
      skill_level,
      experience,
      status = 'pending'
    } = body;

    if (!first_name || !last_name || !email || !skill_level) {
      return NextResponse.json(
        { error: "first_name, last_name, email, and skill_level are required" },
        { status: 400 }
      );
    }

    const result = await sql`
      INSERT INTO membership_applications (
        member_id, first_name, last_name, email, phone, skill_level, experience, status
      )
      VALUES (
        ${member_id || null}, ${first_name}, ${last_name}, ${email}, 
        ${phone || null}, ${skill_level}, ${experience || null}, ${status}
      )
      RETURNING *
    `;

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating membership application:", error);
    return NextResponse.json({ error: "Failed to create membership application" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { id, status, notes, member_id } = body;

    if (!id) {
      return NextResponse.json({ error: "Application id is required" }, { status: 400 });
    }

    const reviewed_at = status ? new Date().toISOString() : null;

    const result = await sql`
      UPDATE membership_applications 
      SET 
        status = COALESCE(${status}, status),
        notes = COALESCE(${notes}, notes),
        member_id = COALESCE(${member_id}, member_id),
        reviewed_at = COALESCE(${reviewed_at}, reviewed_at)
      WHERE id = ${id}
      RETURNING *
    `;

    if (result.length === 0) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating membership application:", error);
    return NextResponse.json({ error: "Failed to update membership application" }, { status: 500 });
  }
}