import sql from "@/app/api/utils/sql";
import { NextResponse } from "next/server";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const event_id = searchParams.get("event_id");
    const member_id = searchParams.get("member_id");
    const status = searchParams.get("status");

    let registrations;
    if (event_id && member_id) {
      registrations = await sql`
        SELECT er.*, e.name as event_name, e.event_date, e.start_time,
               m.first_name, m.last_name, m.email
        FROM event_registrations er
        JOIN events e ON er.event_id = e.id
        JOIN members m ON er.member_id = m.id
        WHERE er.event_id = ${event_id} AND er.member_id = ${member_id}
        ORDER BY er.registered_at DESC
      `;
    } else if (event_id) {
      if (status) {
        registrations = await sql`
          SELECT er.*, m.first_name, m.last_name, m.email
          FROM event_registrations er
          JOIN members m ON er.member_id = m.id
          WHERE er.event_id = ${event_id} AND er.status = ${status}
          ORDER BY er.registered_at ASC
        `;
      } else {
        registrations = await sql`
          SELECT er.*, m.first_name, m.last_name, m.email
          FROM event_registrations er
          JOIN members m ON er.member_id = m.id
          WHERE er.event_id = ${event_id}
          ORDER BY er.registered_at ASC
        `;
      }
    } else if (member_id) {
      registrations = await sql`
        SELECT er.*, e.name as event_name, e.event_date, e.start_time, e.location
        FROM event_registrations er
        JOIN events e ON er.event_id = e.id
        WHERE er.member_id = ${member_id}
        ORDER BY e.event_date DESC
      `;
    } else {
      registrations = await sql`
        SELECT er.*, e.name as event_name, e.event_date,
               m.first_name, m.last_name, m.email
        FROM event_registrations er
        JOIN events e ON er.event_id = e.id
        JOIN members m ON er.member_id = m.id
        ORDER BY er.registered_at DESC
      `;
    }

    return NextResponse.json(registrations);
  } catch (error) {
    console.error("Error fetching event registrations:", error);
    return NextResponse.json({ error: "Failed to fetch event registrations" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      event_id,
      member_id,
      registration_type = 'registration',
      status = 'confirmed'
    } = body;

    if (!event_id || !member_id) {
      return NextResponse.json(
        { error: "event_id and member_id are required" },
        { status: 400 }
      );
    }

    const result = await sql`
      INSERT INTO event_registrations (
        event_id, member_id, registration_type, status
      )
      VALUES (
        ${event_id}, ${member_id}, ${registration_type}, ${status}
      )
      RETURNING *
    `;

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating event registration:", error);
    if (error.message?.includes('unique')) {
      return NextResponse.json({ error: "Member already registered for this event" }, { status: 409 });
    }
    return NextResponse.json({ error: "Failed to create event registration" }, { status: 500 });
  }
}