'use client';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import PublicNav from '@/components/PublicNav';
import Footer from '@/components/Footer';
import { addToCart } from '@/lib/cart';

const FALLBACK_PRODUCTS = [
  { id: 'h1', slug: 'performance-hoodie', name: 'Performance Hoodie', price: 85, category: 'Tops', image_url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop', size_options: ['XS','S','M','L','XL','XXL'] },
  { id: 't1', slug: 'pro-court-tee', name: 'Pro Court Tee', price: 45, category: 'Tops', image_url: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800&auto=format&fit=crop', size_options: ['XS','S','M','L','XL','XXL'] },
  { id: 's1', slug: 'agility-shorts', name: 'Agility Shorts', price: 55, category: 'Bottoms', image_url: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?q=80&w=800&auto=format&fit=crop', size_options: ['XS','S','M','L','XL','XXL'] },
  { id: 'c1', slug: 'club-cap', name: 'Club Cap', price: 30, category: 'Accessories', image_url: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=800&auto=format&fit=crop', size_options: ['One Size'] },
  { id: 'k1', slug: 'court-socks', name: 'Court Socks', price: 18, category: 'Accessories', image_url: 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?q=80&w=800&auto=format&fit=crop', size_options: ['S','M','L'] },
];

export default function ShopPage() {
  const router = useRouter();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');
  const [addedId, setAddedId] = useState(null);

  useEffect(() => {
    fetch('/api/products')
      .then(r => r.json())
      .then(data => {
        const valid = Array.isArray(data) ? data.filter(p => p.active !== false && p.name && p.price) : [];
        setProducts(valid.length > 0 ? valid : FALLBACK_PRODUCTS);
      })
      .catch(() => setProducts(FALLBACK_PRODUCTS))
      .finally(() => setLoading(false));
  }, []);

  const categories = ['All', ...new Set(products.map(p => p.category).filter(Boolean))];
  const filtered = filter === 'All' ? products : products.filter(p => p.category === filter);

  const handleQuickAdd = (e, product) => {
    e.stopPropagation();
    const sizes = Array.isArray(product.size_options) ? product.size_options : [];
    addToCart({ id: product.id, name: product.name, price: parseFloat(product.price), image: product.image_url, size: sizes[0] || 'One Size' });
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  const goToProduct = (product) => {
    router.push(`/product/${product.slug || product.id}`);
  };

  return (
    <div className="font-sans bg-white text-black antialiased">
      <PublicNav />
      <main className="pt-20">

        {/* Header */}
        <section className="py-20 md:py-28 bg-black text-white">
          <div className="max-w-[1600px] mx-auto px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <p className="text-gray-500 text-xs uppercase tracking-widest font-bold mb-4">Club NEVA</p>
                <h1 className="font-display text-6xl md:text-8xl font-medium tracking-tighter uppercase mb-4">The Armory</h1>
                <p className="text-gray-400 text-lg font-light max-w-xl">Performance apparel designed for the court. Members redeem NEVA Cash for exclusive discounts.</p>
              </div>
              <div className="flex items-center gap-2 bg-white/10 border border-white/20 px-4 py-2.5 rounded-full w-fit">
                <i className="ph-fill ph-coin text-amber-400 text-lg"></i>
                <p className="text-sm font-medium uppercase tracking-wide">NEVA Cash Accepted</p>
              </div>
            </div>
          </div>
        </section>

        {/* Filter Bar */}
        {categories.length > 1 && (
          <div className="sticky top-20 z-40 bg-white border-b border-gray-200 shadow-sm">
            <div className="max-w-[1600px] mx-auto px-6 py-4 flex items-center gap-3 overflow-x-auto scrollbar-none">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`px-5 py-2 text-xs font-bold uppercase tracking-widest rounded-full whitespace-nowrap transition-all ${filter === cat ? 'bg-black text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                  {cat}
                </button>
              ))}
              <span className="ml-auto text-xs text-gray-400 whitespace-nowrap">{filtered.length} items</span>
            </div>
          </div>
        )}

        {/* Product Grid */}
        <section className="py-12 md:py-16">
          <div className="max-w-[1600px] mx-auto px-6">
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-12">
                {[1,2,3,4,5,6,7,8].map(i => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-[4/5] bg-gray-100 rounded-xl mb-4"></div>
                    <div className="h-4 bg-gray-100 rounded mb-2 w-3/4"></div>
                    <div className="h-4 bg-gray-100 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-24">
                <i className="ph ph-package text-5xl text-gray-300 mb-4"></i>
                <p className="text-gray-500 text-lg">No products in this category right now.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-12">
                {filtered.map(product => (
                  <div key={product.id} className="group cursor-pointer" onClick={() => goToProduct(product)}>
                    <div className="aspect-[4/5] bg-gray-100 mb-4 overflow-hidden rounded-xl relative">
                      {product.image_url ? (
                        <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gray-100">
                          <i className="ph ph-shirt text-5xl text-gray-300"></i>
                        </div>
                      )}
                      {/* Quick add overlay */}
                      <div className="absolute inset-x-4 bottom-4">
                        <button
                          onClick={(e) => handleQuickAdd(e, product)}
                          className={`w-full py-3 text-xs font-bold uppercase tracking-widest rounded-lg shadow-lg transition-all duration-200 ${
                            addedId === product.id
                              ? 'bg-green-500 text-white translate-y-0 opacity-100'
                              : 'bg-black text-white translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100'
                          }`}
                        >
                          {addedId === product.id ? '✓ Added to Cart' : 'Quick Add'}
                        </button>
                      </div>
                    </div>
                    {product.category && (
                      <p className="text-gray-400 text-[11px] font-bold uppercase tracking-widest mb-1">{product.category}</p>
                    )}
                    <h3 className="font-medium text-base uppercase mb-1 group-hover:text-gray-600 transition-colors">{product.name}</h3>
                    <p className="font-bold text-gray-800">${parseFloat(product.price || 0).toFixed(2)}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* NEVA Cash Banner */}
        <section className="py-16 bg-black text-white">
          <div className="max-w-3xl mx-auto px-6 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <i className="ph-fill ph-coin text-3xl text-amber-400"></i>
              <h2 className="font-display text-3xl font-medium uppercase tracking-tight">Pay With NEVA Cash</h2>
            </div>
            <p className="text-gray-400 mb-8">Members earn NEVA Cash through wins and event performance. Apply it directly at checkout for instant discounts on any item.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button onClick={() => router.push('/membership-apply')} className="px-8 py-4 bg-white text-black font-bold uppercase text-sm tracking-widest rounded hover:bg-gray-200 transition-all">
                Apply for Membership
              </button>
              <button onClick={() => router.push('/login')} className="px-8 py-4 border border-white/30 text-white font-bold uppercase text-sm tracking-widest rounded hover:bg-white/10 transition-all">
                Member Login
              </button>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
