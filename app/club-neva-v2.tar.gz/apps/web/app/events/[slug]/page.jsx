'use client';

import { useRouter, useParams } from 'next/navigation';
import { useState, useEffect } from 'react';
import PublicNav from '@/components/PublicNav';
import { isApprovedMember, isLoggedIn, setLoginRedirect } from '@/lib/auth';

export default function EventDetailPage() {
  const router = useRouter();
  const params = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [isMember, setIsMember] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    setIsMember(isApprovedMember());
    setLoggedIn(isLoggedIn());
    if (params?.slug) fetchEvent();
  }, [params?.slug]);

  const fetchEvent = async () => {
    try {
      const res = await fetch('/api/events');
      const events = await res.json();
      const ev = Array.isArray(events)
        ? events.find(e => e.slug === params.slug || String(e.id) === params.slug)
        : null;

      if (!ev) { router.replace('/events'); return; }
      setEvent(ev);
    } catch {
      router.replace('/events');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!isMember) {
      if (!loggedIn) {
        setLoginRedirect(`/events/${params.slug}`);
        router.push('/membership-apply');
      } else {
        router.push('/portal-dashboard');
      }
      return;
    }
    setRegistering(true);
    // TODO: wire to event-registrations API
    await new Promise(r => setTimeout(r, 800));
    setRegistered(true);
    setRegistering(false);
  };

  if (loading) return (
    <div className="font-sans bg-black text-white min-h-screen">
      <PublicNav />
      <div className="pt-20 flex items-center justify-center min-h-screen">
        <p className="text-gray-400 text-sm uppercase tracking-widest">Loading Event...</p>
      </div>
    </div>
  );

  if (!event) return null;

  const date = event.date_time ? new Date(event.date_time) : null;
  const capacity = event.capacity || event.spots_total;
  const registered_count = event.registered_count || event.spots_taken || 0;
  const spotsLeft = capacity ? capacity - registered_count : null;

  return (
    <div className="font-sans bg-black text-white antialiased">
      <PublicNav />
      <main className="pt-20">
        {/* Event Hero */}
        <div className="relative h-72 md:h-96 bg-gray-900 overflow-hidden">
          {event.image_url ? (
            <img src={event.image_url} alt={event.title} className="w-full h-full object-cover opacity-60" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
              <i className="ph ph-trophy text-8xl text-gray-700"></i>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 p-8 max-w-5xl mx-auto">
            <button onClick={() => router.push('/events')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 text-sm uppercase tracking-wide">
              <i className="ph ph-arrow-left"></i> All Events
            </button>
            <h1 className="font-display text-4xl md:text-6xl font-medium uppercase tracking-tight">{event.title || event.name}</h1>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-6 py-12">
          <div className="grid md:grid-cols-3 gap-12">
            {/* Event Info */}
            <div className="md:col-span-2">
              {event.description && (
                <div className="mb-10">
                  <h2 className="font-display text-2xl uppercase font-bold tracking-tight mb-4 border-b border-white/10 pb-4">About This Event</h2>
                  <p className="text-gray-300 leading-relaxed">{event.description}</p>
                </div>
              )}

              {event.rules && (
                <div className="mb-10">
                  <h2 className="font-display text-2xl uppercase font-bold tracking-tight mb-4 border-b border-white/10 pb-4">Rules & Notes</h2>
                  <p className="text-gray-300 leading-relaxed">{event.rules}</p>
                </div>
              )}

              {/* Details Grid */}
              <div className="grid grid-cols-2 gap-4">
                {date && (
                  <div className="bg-white/5 border border-white/10 rounded-xl p-5">
                    <p className="text-gray-500 text-xs uppercase tracking-widest mb-2">Date & Time</p>
                    <p className="font-bold">{date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                    <p className="text-gray-400 text-sm mt-1">{date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</p>
                  </div>
                )}
                {event.location && (
                  <div className="bg-white/5 border border-white/10 rounded-xl p-5">
                    <p className="text-gray-500 text-xs uppercase tracking-widest mb-2">Location</p>
                    <p className="font-bold">{event.location}</p>
                  </div>
                )}
                {event.price && (
                  <div className="bg-white/5 border border-white/10 rounded-xl p-5">
                    <p className="text-gray-500 text-xs uppercase tracking-widest mb-2">Entry Fee</p>
                    <p className="font-bold text-lg">${parseFloat(event.price).toFixed(2)}</p>
                  </div>
                )}
                {capacity && (
                  <div className="bg-white/5 border border-white/10 rounded-xl p-5">
                    <p className="text-gray-500 text-xs uppercase tracking-widest mb-2">Spots</p>
                    <p className="font-bold">{registered_count} / {capacity} filled</p>
                    {spotsLeft !== null && spotsLeft > 0 && (
                      <p className={`text-sm mt-1 ${spotsLeft <= 3 ? 'text-orange-400' : 'text-green-400'}`}>{spotsLeft} remaining</p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Registration Card */}
            <div className="md:col-span-1">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-8 sticky top-28">
                <h3 className="font-display text-xl uppercase font-bold tracking-tight mb-6">Registration</h3>

                {registered ? (
                  <div className="text-center py-4">
                    <div className="w-14 h-14 bg-green-500/20 border border-green-500/30 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ph-fill ph-check-circle text-3xl text-green-400"></i>
                    </div>
                    <p className="font-bold text-green-400 mb-2">You're Registered!</p>
                    <p className="text-gray-400 text-sm">See you at the event.</p>
                    <button onClick={() => router.push('/portal-dashboard')} className="mt-4 w-full py-3 bg-white/10 text-white text-sm font-bold uppercase tracking-widest rounded hover:bg-white/20 transition-colors">
                      View Portal
                    </button>
                  </div>
                ) : (
                  <>
                    {event.price && <p className="text-3xl font-bold mb-6">${parseFloat(event.price).toFixed(2)}</p>}

                    <button
                      onClick={handleRegister}
                      disabled={registering || (spotsLeft !== null && spotsLeft <= 0)}
                      className={`w-full py-4 font-bold uppercase text-sm tracking-widest rounded-xl transition-all active:scale-95 mb-4 disabled:opacity-50 disabled:cursor-not-allowed ${isMember ? 'bg-white text-black hover:bg-gray-200' : 'bg-white/20 text-white hover:bg-white/30 border border-white/20'}`}
                    >
                      {registering ? 'Registering...' :
                       spotsLeft !== null && spotsLeft <= 0 ? 'Event Full' :
                       isMember ? 'Register Now' : 'Apply to Join →'}
                    </button>

                    {!isMember && (
                      <p className="text-gray-500 text-xs text-center">
                        {loggedIn ? 'Your membership is pending review.' : 'Membership required to register.'}
                      </p>
                    )}

                    {isMember && (
                      <div className="mt-4 pt-4 border-t border-white/10">
                        <p className="text-gray-500 text-xs text-center">Members only. Secure registration.</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
