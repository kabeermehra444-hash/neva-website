'use client';
import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import PortalNav from '@/components/PortalNav';
import { isAdmin, setLoginRedirect } from '@/lib/auth';

export default function PortalAdminPage() {
  const router = useRouter();
  const [tab, setTab] = useState('applications');
  const [applications, setApplications] = useState([]);
  const [members, setMembers] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingMember, setEditingMember] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!isAdmin()) {
      router.replace('/portal-dashboard');
      return;
    }
    fetchAll();
  }, []);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [appsRes, memsRes, evRes] = await Promise.all([
        fetch('/api/membership-applications'),
        fetch('/api/members'),
        fetch('/api/events'),
      ]);
      setApplications(await appsRes.json().then(d => Array.isArray(d) ? d : []));
      setMembers(await memsRes.json().then(d => Array.isArray(d) ? d : []));
      setEvents(await evRes.json().then(d => Array.isArray(d) ? d : []));
    } catch (e) { showToast('Error loading data', 'error'); }
    finally { setLoading(false); }
  };

  const approveApp = async (app) => {
    try {
      const res = await fetch('/api/members', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ first_name: app.first_name, last_name: app.last_name, email: app.email, phone: app.phone, status: 'active', is_admin: false, neva_cash_balance: 0 }),
      });
      await fetch(`/api/membership-applications/${app.id}`, {
        method: 'PATCH', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ status: 'approved' }),
      }).catch(() => {});
      if (res.ok || res.status === 409) {
        showToast(`✓ Approved: ${app.first_name} ${app.last_name}`);
        fetchAll();
      } else { showToast('Error approving', 'error'); }
    } catch { showToast('Error approving', 'error'); }
  };

  const denyApp = async (app) => {
    if (!confirm(`Deny ${app.first_name} ${app.last_name}?`)) return;
    await fetch(`/api/membership-applications/${app.id}`, {
      method: 'PATCH', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ status: 'denied' }),
    }).catch(() => {});
    showToast(`Denied: ${app.first_name} ${app.last_name}`);
    fetchAll();
  };

  const startEdit = (m) => {
    setEditingMember(m.id);
    setEditForm({ wins: m.wins||0, losses: m.losses||0, events_played: m.events_played||0, streak: m.streak||0, neva_cash_balance: m.neva_cash_balance||0, rank_label: m.rank_label||'', status: m.status||'active', is_admin: m.is_admin||false });
  };

  const saveMember = async (id) => {
    setSaving(true);
    const res = await fetch(`/api/members/${id}`, {
      method: 'PATCH', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ wins: +editForm.wins, losses: +editForm.losses, events_played: +editForm.events_played, streak: +editForm.streak, neva_cash_balance: +editForm.neva_cash_balance, rank_label: editForm.rank_label, status: editForm.status, is_admin: editForm.is_admin }),
    });
    setSaving(false);
    if (res.ok) { showToast('✓ Member updated'); setEditingMember(null); fetchAll(); }
    else showToast('Error saving', 'error');
  };

  const pending = applications.filter(a => a.status === 'pending');
  const reviewed = applications.filter(a => a.status !== 'pending');
  const filteredMembers = search ? members.filter(m => `${m.first_name} ${m.last_name} ${m.email}`.toLowerCase().includes(search.toLowerCase())) : members;

  const stats = [
    { label: 'Total Members', value: members.filter(m=>m.status==='active'||m.status==='approved').length, icon: 'ph-users', color: 'text-blue-400' },
    { label: 'Pending Apps', value: pending.length, icon: 'ph-clock', color: 'text-yellow-400' },
    { label: 'Total Events', value: events.length, icon: 'ph-calendar', color: 'text-green-400' },
    { label: 'NEVA Cash Issued', value: '$'+members.reduce((s,m)=>s+(+m.neva_cash_balance||0),0).toFixed(0), icon: 'ph-coin', color: 'text-amber-400' },
  ];

  if (loading) return (
    <div className="font-sans bg-black text-white min-h-screen flex items-center justify-center">
      <p className="text-gray-500 text-xs uppercase tracking-widest">Loading Admin...</p>
    </div>
  );

  return (
    <div className="font-sans bg-black text-white antialiased min-h-screen">
      <PortalNav />

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-6 py-3 rounded-xl font-bold text-sm shadow-2xl transition-all ${toast.type==='error' ? 'bg-red-500 text-white' : 'bg-white text-black'}`}>
          {toast.msg}
        </div>
      )}

      <main className="pt-20 pb-16">
        <div className="max-w-[1600px] mx-auto px-6">

          {/* Header */}
          <section className="py-8 border-b border-white/10 mb-8">
            <div className="flex items-center gap-3 mb-1">
              <span className="px-2.5 py-1 bg-yellow-400/20 border border-yellow-400/40 rounded text-yellow-400 text-[11px] font-bold uppercase tracking-widest">Admin</span>
              <h1 className="font-display text-4xl font-medium uppercase tracking-tight">Control Panel</h1>
            </div>
            <p className="text-gray-500">{members.filter(m=>m.status==='active'||m.status==='approved').length} active members · {pending.length} pending applications</p>
          </section>

          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {stats.map(s => (
              <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-5">
                <div className="flex items-start justify-between mb-3">
                  <p className="text-gray-500 text-[11px] uppercase tracking-widest font-bold">{s.label}</p>
                  <i className={`ph-fill ${s.icon} text-lg ${s.color}`}></i>
                </div>
                <p className="font-display text-3xl font-bold">{s.value}</p>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mb-8 border-b border-white/10">
            {[
              { key: 'applications', label: `Applications`, badge: pending.length },
              { key: 'members', label: 'Members', badge: null },
              { key: 'events', label: 'Events', badge: null },
            ].map(t => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`px-5 py-3 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors flex items-center gap-2 ${tab===t.key ? 'border-white text-white' : 'border-transparent text-gray-500 hover:text-white'}`}
              >
                {t.label}
                {t.badge > 0 && <span className="bg-yellow-400 text-black text-[10px] font-bold px-1.5 py-0.5 rounded-full">{t.badge}</span>}
              </button>
            ))}
          </div>

          {/* APPLICATIONS TAB */}
          {tab === 'applications' && (
            <div>
              {pending.length === 0 ? (
                <div className="text-center py-20 text-gray-500">
                  <i className="ph ph-check-circle text-5xl mb-4 text-green-500/50"></i>
                  <p>No pending applications — inbox clear.</p>
                </div>
              ) : (
                <div className="space-y-4 mb-12">
                  <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest mb-4">Awaiting Review ({pending.length})</p>
                  {pending.map(app => (
                    <div key={app.id} className="bg-white/5 border border-white/10 rounded-xl p-6 hover:border-white/20 transition-colors">
                      <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 flex-wrap mb-2">
                            <h3 className="font-bold text-lg">{app.first_name} {app.last_name}</h3>
                            {app.skill_level && <span className="text-[11px] bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded font-bold uppercase">{app.skill_level}</span>}
                          </div>
                          <p className="text-gray-400 text-sm mb-1">{app.email}{app.phone ? ` · ${app.phone}` : ''}</p>
                          {app.instagram_handle && <p className="text-gray-500 text-sm mb-1">@{app.instagram_handle}</p>}
                          {app.experience && <p className="text-gray-500 text-sm mb-2">Plays: {app.experience}</p>}
                          {app.why_join && (
                            <div className="mt-3 p-4 bg-white/5 rounded-lg border border-white/10">
                              <p className="text-[11px] text-gray-500 uppercase tracking-widest mb-1">Why they want to join</p>
                              <p className="text-sm text-gray-300 leading-relaxed">{app.why_join}</p>
                            </div>
                          )}
                          <p className="text-gray-600 text-xs mt-3">Submitted {app.submitted_at ? new Date(app.submitted_at).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'}) : '—'}</p>
                        </div>
                        <div className="flex gap-2 flex-shrink-0">
                          <button onClick={() => approveApp(app)} className="px-5 py-2.5 bg-green-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-green-600 transition-colors">
                            Approve
                          </button>
                          <button onClick={() => denyApp(app)} className="px-5 py-2.5 bg-red-500/20 border border-red-500/30 text-red-400 font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-red-500/30 transition-colors">
                            Deny
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {reviewed.length > 0 && (
                <div>
                  <p className="text-gray-600 text-xs font-bold uppercase tracking-widest mb-4">Previously Reviewed</p>
                  <div className="space-y-2">
                    {reviewed.map(app => (
                      <div key={app.id} className="bg-white/3 border border-white/5 rounded-lg px-5 py-3 flex items-center justify-between">
                        <div>
                          <span className="text-sm font-medium">{app.first_name} {app.last_name}</span>
                          <span className="text-gray-500 text-sm ml-3">{app.email}</span>
                        </div>
                        <span className={`text-[11px] font-bold uppercase px-2 py-0.5 rounded ${app.status==='approved' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{app.status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* MEMBERS TAB */}
          {tab === 'members' && (
            <div>
              {/* Search */}
              <div className="relative mb-6">
                <i className="ph ph-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
                <input
                  type="text" value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search by name or email..."
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-white/30 placeholder-gray-600"
                />
              </div>

              <div className="space-y-3">
                {filteredMembers.map(m => (
                  <div key={m.id} className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
                    {editingMember === m.id ? (
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-5">
                          <h3 className="font-bold">{m.first_name} {m.last_name}</h3>
                          <div className="flex gap-2">
                            <button onClick={() => saveMember(m.id)} disabled={saving} className="px-4 py-2 bg-white text-black font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50">
                              {saving ? 'Saving...' : 'Save Changes'}
                            </button>
                            <button onClick={() => setEditingMember(null)} className="px-4 py-2 bg-white/10 text-white font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-white/20 transition-colors">
                              Cancel
                            </button>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {[
                            {label:'Wins',key:'wins',type:'number'},
                            {label:'Losses',key:'losses',type:'number'},
                            {label:'Events Played',key:'events_played',type:'number'},
                            {label:'Current Streak',key:'streak',type:'number'},
                            {label:'NEVA Cash ($)',key:'neva_cash_balance',type:'number'},
                            {label:'Rank Label',key:'rank_label',type:'text'},
                          ].map(f => (
                            <div key={f.key}>
                              <label className="block text-[11px] font-bold uppercase tracking-widest text-gray-500 mb-1.5">{f.label}</label>
                              <input type={f.type} value={editForm[f.key]} onChange={e => setEditForm({...editForm,[f.key]:e.target.value})}
                                className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:outline-none focus:border-white/50" />
                            </div>
                          ))}
                          <div>
                            <label className="block text-[11px] font-bold uppercase tracking-widest text-gray-500 mb-1.5">Status</label>
                            <select value={editForm.status} onChange={e => setEditForm({...editForm,status:e.target.value})}
                              className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:outline-none">
                              <option value="active" className="bg-black">Active</option>
                              <option value="pending" className="bg-black">Pending</option>
                              <option value="denied" className="bg-black">Denied</option>
                            </select>
                          </div>
                          <div className="flex items-center gap-3 mt-5">
                            <input type="checkbox" id={`adm-${m.id}`} checked={editForm.is_admin} onChange={e => setEditForm({...editForm,is_admin:e.target.checked})} className="w-4 h-4 cursor-pointer" />
                            <label htmlFor={`adm-${m.id}`} className="text-[11px] font-bold uppercase tracking-widest text-gray-400 cursor-pointer">Admin Access</label>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="px-5 py-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <span className="font-bold">{m.first_name} {m.last_name}</span>
                            {m.is_admin && <span className="text-[10px] bg-yellow-400/20 text-yellow-400 border border-yellow-400/30 px-1.5 py-0.5 rounded font-bold uppercase">Admin</span>}
                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${m.status==='active'||m.status==='approved' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>{m.status}</span>
                          </div>
                          <p className="text-gray-500 text-sm">{m.email}</p>
                          <div className="flex flex-wrap gap-4 mt-1.5 text-xs text-gray-600">
                            <span>{m.wins||0}W / {m.losses||0}L</span>
                            <span>Events: {m.events_played||0}</span>
                            <span>NEVA Cash: ${m.neva_cash_balance||0}</span>
                            {m.streak > 0 && <span>Streak: {m.streak}</span>}
                            {m.rank_label && <span>Rank: {m.rank_label}</span>}
                          </div>
                        </div>
                        <button onClick={() => startEdit(m)} className="px-4 py-2 bg-white/10 border border-white/20 text-white font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-white/20 transition-colors flex-shrink-0">
                          Edit
                        </button>
                      </div>
                    )}
                  </div>
                ))}
                {filteredMembers.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <i className="ph ph-magnifying-glass text-3xl mb-3"></i>
                    <p>No members match "{search}"</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* EVENTS TAB */}
          {tab === 'events' && (
            <div>
              {events.length === 0 ? (
                <div className="text-center py-20 text-gray-500">
                  <i className="ph ph-calendar text-4xl mb-4"></i>
                  <p>No events in the database yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {events.map(ev => {
                    const d = ev.date_time ? new Date(ev.date_time) : null;
                    return (
                      <div key={ev.id} className="bg-white/5 border border-white/10 rounded-xl px-5 py-4">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <p className="font-bold mb-1">{ev.title||ev.name}</p>
                            <div className="flex flex-wrap gap-4 text-xs text-gray-500">
                              {d && <span>{d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</span>}
                              {ev.location && <span>{ev.location}</span>}
                              {ev.price && <span>${parseFloat(ev.price).toFixed(2)} entry</span>}
                              <span className={`font-bold uppercase ${ev.status==='upcoming' ? 'text-green-400' : 'text-gray-500'}`}>{ev.status}</span>
                            </div>
                          </div>
                          <button onClick={() => router.push(`/events/${ev.slug||ev.id}`)} className="px-3 py-1.5 bg-white/10 text-white font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-white/20 transition-colors flex-shrink-0">
                            View
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
