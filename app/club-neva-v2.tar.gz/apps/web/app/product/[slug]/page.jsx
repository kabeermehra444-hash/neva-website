'use client';

import { useRouter, useParams } from 'next/navigation';
import { useState, useEffect } from 'react';
import PublicNav from '@/components/PublicNav';
import { addToCart } from '@/lib/cart';

export default function ProductPage() {
  const router = useRouter();
  const params = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState('');
  const [added, setAdded] = useState(false);
  const [qty, setQty] = useState(1);

  useEffect(() => {
    if (!params?.slug) return;
    fetchProduct();
  }, [params?.slug]);

  const fetchProduct = async () => {
    try {
      const res = await fetch('/api/products');
      const products = await res.json();
      const match = Array.isArray(products)
        ? products.find(p => p.slug === params.slug || String(p.id) === params.slug)
        : null;

      if (!match) {
        router.replace('/shop');
        return;
      }
      setProduct(match);
      const sizes = Array.isArray(match.size_options) ? match.size_options : [];
      if (sizes.length > 0) setSelectedSize(sizes[0]);
      else setSelectedSize('One Size');
    } catch {
      router.replace('/shop');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = () => {
    if (!product) return;
    for (let i = 0; i < qty; i++) {
      addToCart({
        id: product.id,
        name: product.name,
        price: parseFloat(product.price),
        image: product.image_url,
        size: selectedSize,
      });
    }
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  if (loading) {
    return (
      <div className="font-sans bg-white text-black antialiased min-h-screen">
        <PublicNav />
        <div className="pt-20 flex items-center justify-center min-h-screen">
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto px-6 w-full animate-pulse">
            <div className="aspect-square bg-gray-100 rounded-xl"></div>
            <div className="space-y-6 pt-8">
              <div className="h-10 bg-gray-100 rounded w-3/4"></div>
              <div className="h-8 bg-gray-100 rounded w-1/4"></div>
              <div className="h-4 bg-gray-100 rounded"></div>
              <div className="h-4 bg-gray-100 rounded w-5/6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) return null;

  const sizes = Array.isArray(product.size_options) ? product.size_options : [];
  const price = parseFloat(product.price || 0);

  return (
    <div className="font-sans bg-white text-black antialiased">
      <PublicNav />
      <main className="pt-20">
        <div className="max-w-6xl mx-auto px-6 py-16">
          <button onClick={() => router.push('/shop')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-black transition-colors mb-10 uppercase tracking-wide">
            <i className="ph ph-caret-left"></i> Back to Shop
          </button>

          <div className="grid md:grid-cols-2 gap-16 items-start">
            {/* Image */}
            <div className="aspect-square bg-gray-100 rounded-2xl overflow-hidden sticky top-28">
              {product.image_url ? (
                <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <i className="ph ph-shirt text-8xl text-gray-300"></i>
                </div>
              )}
            </div>

            {/* Details */}
            <div className="py-4">
              {product.category && (
                <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-4">{product.category}</p>
              )}
              <h1 className="font-display text-4xl md:text-5xl font-medium tracking-tight uppercase mb-4">{product.name}</h1>
              <p className="text-3xl font-bold mb-8">${price.toFixed(2)}</p>

              {product.description && (
                <p className="text-gray-600 leading-relaxed mb-8">{product.description}</p>
              )}

              {/* Size selector */}
              {sizes.length > 0 && (
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-bold uppercase tracking-widest">Size</p>
                    <span className="text-sm text-gray-500">{selectedSize}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {sizes.map(size => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-4 py-2.5 border text-sm font-bold uppercase tracking-wide rounded transition-all ${
                          selectedSize === size
                            ? 'bg-black text-white border-black'
                            : 'border-gray-300 text-gray-700 hover:border-black'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Qty */}
              <div className="mb-8">
                <p className="text-sm font-bold uppercase tracking-widest mb-3">Quantity</p>
                <div className="flex items-center gap-3 border border-gray-300 rounded w-fit">
                  <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-4 py-3 hover:bg-gray-100 transition-colors text-lg">-</button>
                  <span className="px-4 font-bold text-lg w-8 text-center">{qty}</span>
                  <button onClick={() => setQty(qty + 1)} className="px-4 py-3 hover:bg-gray-100 transition-colors text-lg">+</button>
                </div>
              </div>

              {/* Add to Cart */}
              <button
                onClick={handleAddToCart}
                className={`w-full py-5 font-bold uppercase text-sm tracking-widest rounded-xl transition-all active:scale-95 mb-4 ${
                  added
                    ? 'bg-green-500 text-white'
                    : 'bg-black text-white hover:bg-gray-800'
                }`}
              >
                {added ? '✓ Added to Cart' : `Add to Cart — $${(price * qty).toFixed(2)}`}
              </button>

              <button
                onClick={() => { handleAddToCart(); router.push('/checkout'); }}
                className="w-full py-5 bg-transparent border-2 border-black text-black font-bold uppercase text-sm tracking-widest rounded-xl hover:bg-gray-50 active:scale-95 transition-all"
              >
                Buy Now
              </button>

              {/* Details */}
              <div className="mt-10 pt-8 border-t border-gray-200 space-y-3">
                {[
                  { icon: 'ph-truck', text: 'Free shipping on all orders' },
                  { icon: 'ph-arrow-counter-clockwise', text: '30-day returns' },
                  { icon: 'ph-shield-check', text: 'Secure checkout' },
                ].map(item => (
                  <div key={item.text} className="flex items-center gap-3 text-sm text-gray-600">
                    <i className={`ph-fill ${item.icon} text-xl`}></i>
                    <span>{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
